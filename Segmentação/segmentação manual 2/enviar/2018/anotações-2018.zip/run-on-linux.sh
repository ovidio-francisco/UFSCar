java -jar TextSegmentationTool.jar
